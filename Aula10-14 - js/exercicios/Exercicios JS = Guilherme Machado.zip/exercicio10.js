// Escreva um algoritmo que calcule e imprima a tabuada do 2,3,4,5,6,7,8,9,10 (1 a 10) 

numUm = 2;


cont = 0;

while(cont <= 10){
    numDois = 0;
    while(numDois <= 10){
        res = numUm * numDois
        console.log(numUm, "x", numDois, "=", res);
        numDois += 1
    }
    numUm +=1
    cont += 1
    console.log("===============================")
}