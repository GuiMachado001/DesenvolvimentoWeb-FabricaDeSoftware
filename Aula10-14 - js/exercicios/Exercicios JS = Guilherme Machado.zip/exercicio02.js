// Mostrar os números 11, 21, 31 … 101. 

var cont = 11;

while(cont <= 101){
    console.log(cont);
    cont += 10
}